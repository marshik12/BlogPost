package com.blogapp.commentservice.service;

import com.blogapp.postservice.dto.APIResonseDto;
import com.blogapp.commentservice.dto.CommentDto;

import java.util.List;

public interface CommentService {
    CommentDto createComment(CommentDto commentDto);

    List<CommentDto> getCommentsByPostId();

    CommentDto getCommentById(long commentId);

}
