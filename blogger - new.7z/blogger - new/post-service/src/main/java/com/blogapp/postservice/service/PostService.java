package com.blogapp.postservice.service;

import com.blogapp.postservice.dto.APIResonseDto;
import com.blogapp.postservice.dto.PostDto;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostService{
    PostDto createPost(PostDto postDto);

    List<PostDto> getAllPosts();

    APIResonseDto getByPostId(long id);

}
