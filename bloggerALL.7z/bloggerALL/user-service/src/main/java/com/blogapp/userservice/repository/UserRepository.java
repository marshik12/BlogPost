package com.blogapp.userservice.repository;

import com.blogapp.userservice.dto.RegisterDto;
import com.blogapp.userservice.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface UserRepository extends JpaRepository<User,Long> {

    Optional<User> findByEmail(String email);

    Optional<User> findByUsernameOrEmail(String username,String email);

    Optional<User> findByUsername(String username);

    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);

    List<User> findByFollowing(User user);

    /*@Query("SELECT u FROM User u WHERE u.follower.userId = :followerId")
    List<User> findFollowersByUserId(@Param("followerId") Long followerId);*/

    @Query("SELECT u.followers FROM User u WHERE u.id = :id")
    Set<User> findFollowersById(@Param("id") Long id);


}