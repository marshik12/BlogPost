package com.blogapp.userservice.service;

import com.blogapp.userservice.dto.*;
import com.blogapp.userservice.entity.User;

import java.util.List;

public interface AuthService {

    String register(RegisterDto registerDto);

    List<RegisterDto> getAllUsers();

    APIResonseDtoNew getByUserId(long id);

    void followerUser(Long followerId, Long followedId);

    //List<PostDto> getUserPosts(Long userId);

    List<RegisterDto> getFollowers(Long userId);
    List<APIResonseDtoNew> getFollowersAndUser(Long user);

   // List<PostDto> getHomeFeed(Long userId);

    String login(LoginDto loginDto);
}
