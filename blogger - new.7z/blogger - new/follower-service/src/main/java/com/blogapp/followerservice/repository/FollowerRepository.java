package com.blogapp.followerservice.repository;

public interface FollowerRepository {
}
