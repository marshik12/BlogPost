package com.blogapp.userservice.controller;

import com.blogapp.userservice.dto.*;
import com.blogapp.userservice.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    //Build register REST API
    @PostMapping(value = {"/register", "/signup"})
    public ResponseEntity<String> register(@RequestBody RegisterDto registerDto){
        String response = authService.register(registerDto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping(value = {"/register", "/signup"})
    public List<RegisterDto> getAllPosts(){
        return authService.getAllUsers();
    }

    @GetMapping("/register/{userId}")
    public ResponseEntity<APIResonseDtoNew> getByUserId(@PathVariable long userId){
        APIResonseDtoNew apiResonseDtoNew = authService.getByUserId(userId);
        return new ResponseEntity<>(apiResonseDtoNew, HttpStatus.OK);
    }

    @PostMapping("/follow/query")
    public ResponseEntity<String> followUser(@RequestParam Long followerId, @RequestParam Long followedId){
        authService.followerUser(followerId,followedId);
        return ResponseEntity.ok("User followed successfully");
    }

    @GetMapping("/{userId}")
    public List<PostDto> getUserPosts(@PathVariable Long userId){
        return authService.getUserPosts(userId);
    }

    @GetMapping("follower/{userId}")
    public List<PostDto> getFollowers(@PathVariable Long userId){
        return authService.getFollowers(userId);
    }

}
