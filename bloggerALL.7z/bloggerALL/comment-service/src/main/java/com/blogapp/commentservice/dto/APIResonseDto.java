package com.blogapp.commentservice.dto;

import com.blogapp.postservice.dto.CommentDto;
import com.blogapp.postservice.dto.PostDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class APIResonseDto {
    private CommentDto commentDto;
    private PostDto postDto;
}
