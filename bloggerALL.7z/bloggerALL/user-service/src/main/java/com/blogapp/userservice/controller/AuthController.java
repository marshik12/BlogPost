package com.blogapp.userservice.controller;

import com.blogapp.userservice.dto.*;
import com.blogapp.userservice.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    //Build login REST API
    @PostMapping(value = {"/login", "/signin"})
    public ResponseEntity<JWTAuthResponse> login(@RequestBody LoginDto loginDto){
        String token = authService.login(loginDto);

        JWTAuthResponse jwtAuthResponse = new JWTAuthResponse();
        jwtAuthResponse.setAccessToken(token);

        return ResponseEntity.ok(jwtAuthResponse);
    }

    //Build register REST API
    @PostMapping(value = {"/register", "/signup"})
    public ResponseEntity<String> register(@RequestBody RegisterDto registerDto){
        String response = authService.register(registerDto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    //Get all the user details
    @GetMapping(value = {"/register", "/signup"})
    List<RegisterDto> getAllUsers(){
        return authService.getAllUsers();
    }

    //Get user by userId
    @GetMapping("/register/{userId}")
    public ResponseEntity<APIResonseDtoNew> getByUserId(@PathVariable long userId){
        APIResonseDtoNew apiResonseDtoNew = authService.getByUserId(userId);
        return new ResponseEntity<>(apiResonseDtoNew, HttpStatus.OK);
    }

    //Add followers to user
    @PostMapping("/follow/query")
    public ResponseEntity<String> followUser(@RequestParam Long followerId, @RequestParam Long followedId){
        authService.followerUser(followerId,followedId);
        return ResponseEntity.ok("User followed successfully");
    }


    //List of users followers
    @GetMapping("follower/{userId}")
    public List<RegisterDto> getFollowers(@PathVariable Long userId){
        return authService.getFollowers(userId);
    }

    //Combined post feed of users and followers
    @GetMapping("feed/{userId}")
    public List<APIResonseDtoNew> getFollowersAndUser(@PathVariable Long userId){
        return authService.getFollowersAndUser(userId);
    }


}
