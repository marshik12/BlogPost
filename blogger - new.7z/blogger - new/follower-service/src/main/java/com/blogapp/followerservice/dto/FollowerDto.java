package com.blogapp.followerservice.dto;

public class FollowerDto {
}
