package com.blogapp.followerservice.controller;

public class FollowerController {
}
