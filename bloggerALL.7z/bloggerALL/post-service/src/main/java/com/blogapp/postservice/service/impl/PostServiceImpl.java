package com.blogapp.postservice.service.impl;

import com.blogapp.postservice.dto.APIResonseDto;
import com.blogapp.postservice.dto.CommentDto;
import com.blogapp.postservice.dto.PostDto;
import com.blogapp.postservice.entity.Post;
import com.blogapp.postservice.exception.ResourceNotFoundException;
import com.blogapp.postservice.repository.PostRepository;
import com.blogapp.postservice.service.PostService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class PostServiceImpl implements PostService {
    private PostRepository postRepository;

    private ModelMapper mapper;

    private RestTemplate restTemplate;

    @Override
    public PostDto createPost(PostDto postDto) {
        //convert Dto to entity
        Post post = mapToEntity(postDto);

        Post newPost = postRepository.save(post);

        //convert entity to Dto
        PostDto postResponse = mapToDTO(newPost);
        return postResponse;
    }

    @Override
    public List<PostDto> getAllPosts() {
        List<Post> posts = postRepository.findAll();
        return posts.stream().map(post -> mapToDTO(post)).collect(Collectors.toList());
    }

    @Override
    public APIResonseDto getByPostId(long postId) {
        Post post = postRepository.findById(postId).orElseThrow(()-> new ResourceNotFoundException("Post", "id", postId));

        ResponseEntity<CommentDto> responseEntity = restTemplate.getForEntity("http://localhost:8080/api/comments/" + post.getCommentId(),
                CommentDto.class);

        CommentDto commentDto = responseEntity.getBody();
        System.out.println(commentDto);

        PostDto postDto = mapToDTO(post);

        APIResonseDto apiResonseDto = new APIResonseDto();
       apiResonseDto.setPostDto(postDto);
       apiResonseDto.setCommentDto(commentDto);

        return apiResonseDto;
    }


    //convert DTO to entity
    private Post mapToEntity(PostDto postDto){

        Post post = mapper.map(postDto,Post.class);
        /*Post post = new Post();
        post.setTitle(postDto.getTitle());
        post.setDescription(postDto.getDescription());
        post.setContent(postDto.getContent());*/
        return post;
    }

    //convert Entity into DTO
    private PostDto mapToDTO(Post post){

        PostDto postDto = mapper.map(post,PostDto.class);
        /*PostDto postDto = new PostDto();
        postDto.setId(post.getId());
        postDto.setTitle(post.getTitle());
        postDto.setDescription(post.getDescription());
        postDto.setContent(post.getContent());*/
        return postDto;
    }
}
