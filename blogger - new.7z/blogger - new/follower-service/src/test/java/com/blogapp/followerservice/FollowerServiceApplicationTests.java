package com.blogapp.followerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FollowerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
