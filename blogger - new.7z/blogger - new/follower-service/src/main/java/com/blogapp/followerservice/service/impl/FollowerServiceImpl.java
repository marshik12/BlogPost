package com.blogapp.followerservice.service.impl;

public class FollowerServiceImpl {
}
