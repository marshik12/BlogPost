package com.blogapp.followerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FollowerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FollowerServiceApplication.class, args);
	}

}
