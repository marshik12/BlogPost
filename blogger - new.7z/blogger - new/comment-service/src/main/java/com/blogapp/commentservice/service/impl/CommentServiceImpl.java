package com.blogapp.commentservice.service.impl;


import com.blogapp.postservice.dto.APIResonseDto;
import com.blogapp.commentservice.dto.CommentDto;
import com.blogapp.commentservice.entity.Comment;
import com.blogapp.commentservice.repository.CommentRepository;
import com.blogapp.commentservice.service.CommentService;
import com.blogapp.postservice.exception.ResourceNotFoundException;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class CommentServiceImpl implements CommentService {

    private CommentRepository commentRepository;

    private RestTemplate restTemplate;

    private ModelMapper mapper;


    @Override
    public CommentDto createComment(CommentDto commentDto) {

        Comment comment = mapToEntity(commentDto);

        //save entity to database
        Comment newComment = commentRepository.save(comment);
        return mapToDto(newComment);


    }

    @Override
    public List<CommentDto> getCommentsByPostId() {
        //retrieve comments by postId
        List<Comment> comments= commentRepository.findAll();

        //convert list of comment entities to list of comment dto's
        return comments.stream().map(comment -> mapToDto(comment)).collect(Collectors.toList());
    }

    @Override
    public CommentDto getCommentById(long commentId) {
        //retrieve comment by idS
        Comment comment = commentRepository.findById(commentId).orElseThrow(()->
                new ResourceNotFoundException("Comment","id",commentId));

        CommentDto commentDto = mapToDto(comment);

        return commentDto;

    }

    private CommentDto mapToDto(Comment comment){
        CommentDto commentDto = mapper.map(comment,CommentDto.class);
        /*CommentDto commentDto = new CommentDto();
        commentDto.setId(comment.getId());
        commentDto.setName(comment.getName());
        commentDto.setEmail(comment.getEmail());
        commentDto.setBody(comment.getBody());*/
        return commentDto;
    }

    private Comment mapToEntity(CommentDto commentDto){
        Comment comment = mapper.map(commentDto,Comment.class);
        /*Comment comment = new Comment();
        comment.setId(commentDto.getId());
        comment.setName(commentDto.getName());
        comment.setEmail(commentDto.getEmail());
        comment.setBody(commentDto.getBody());*/
        return comment;
    }
}
