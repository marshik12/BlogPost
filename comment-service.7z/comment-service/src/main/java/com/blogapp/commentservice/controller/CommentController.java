package com.blogapp.commentservice.controller;

import com.blogapp.postservice.dto.APIResonseDto;
import com.blogapp.commentservice.dto.CommentDto;
import com.blogapp.commentservice.service.CommentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/comments")
public class CommentController {
    private CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    //Creation of new comment
    @PostMapping
    public ResponseEntity<CommentDto> createComment(@Valid @RequestBody CommentDto commentDto) {
        return new ResponseEntity<>(commentService.createComment(commentDto), HttpStatus.CREATED);
    }

    //Read all comments
    @GetMapping
    public List<CommentDto> getAllComment() {
        return commentService.getAllComment();
    }

    //Read comment by id
    @GetMapping("/{commentId}")
    public ResponseEntity<CommentDto> getCommentById(@PathVariable long commentId) {
        CommentDto apiResonseDto = commentService.getCommentById(commentId);
        return new ResponseEntity<>(apiResonseDto, HttpStatus.OK);
    }



}