package com.blogapp.userservice.controller;

import com.blogapp.userservice.dto.*;
import com.blogapp.userservice.service.AuthService;
import com.blogapp.userservice.utils.AppConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    //Build login REST API
    @PostMapping(value = {"/login", "/signin"})
    public ResponseEntity<JWTAuthResponse> login(@RequestBody LoginDto loginDto){
        String token = authService.login(loginDto);

        JWTAuthResponse jwtAuthResponse = new JWTAuthResponse();
        jwtAuthResponse.setAccessToken(token);

        return ResponseEntity.ok(jwtAuthResponse);
    }

    //Build register REST API
    @PostMapping(value = {"/register", "/signup"})
    public ResponseEntity<String> register(@RequestBody RegisterDto registerDto){
        String response = authService.register(registerDto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    //Get all the user details
    @GetMapping(value = {"/register", "/signup"})
    public UserResponse getAllUsers(
            @RequestParam(value = "pageNo", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER, required = false) int pageNo,
            @RequestParam(value = "pageSize" , defaultValue = AppConstants.DEFAULT_PAGE_SIZE, required = false) int pageSize,
            @RequestParam(value = "sortBy" , defaultValue = AppConstants.DEFAULT_SORT_BY, required = false) String sortBy,
            @RequestParam(value = "sortDir" , defaultValue = AppConstants.DEFAULT_SORT_DIRECTION, required = false) String sortDir
    ){
        // Check if the user is authenticated
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.isAuthenticated()) {
            // User is authenticated, proceed with fetching user details
            return authService.getAllUsers(pageNo, pageSize, sortBy, sortDir);
        } else {
            // Handle unauthenticated user, maybe redirect to the login page
            // or return an error response
            return new UserResponse(); // Modify this accordingly
        }
    }

    //Get user by userId
    @GetMapping("/register/{userId}")
    public ResponseEntity<APIResonseDtoNew> getByUserId(@PathVariable long userId){
        APIResonseDtoNew apiResonseDtoNew = authService.getByUserId(userId);
        return new ResponseEntity<>(apiResonseDtoNew, HttpStatus.OK);
    }

    //Add followers to user
    @PostMapping("/follow/query")
    public ResponseEntity<String> followUser(@RequestParam Long followerId, @RequestParam Long followedId){
        authService.followerUser(followerId,followedId);
        return ResponseEntity.ok("User followed successfully");
    }


    //List of users followers
    @GetMapping("follower/{userId}")
    public List<RegisterDto> getFollowers(@PathVariable Long userId){
        return authService.getFollowers(userId);
    }

    //Combined post feed of users and followers
    @GetMapping("feed/{userId}")
    public List<APIResonseDtoNew> getFollowersAndUser(@PathVariable Long userId){
        return authService.getFollowersAndUser(userId);
    }


}
