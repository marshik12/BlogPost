package com.blogapp.followerservice.service;

public interface FollowerService {
}
