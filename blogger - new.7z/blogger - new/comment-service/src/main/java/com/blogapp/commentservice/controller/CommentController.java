package com.blogapp.commentservice.controller;

import com.blogapp.postservice.dto.APIResonseDto;
import com.blogapp.commentservice.dto.CommentDto;
import com.blogapp.commentservice.service.CommentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/comments")
public class CommentController {
    private CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @PostMapping
    public ResponseEntity<CommentDto> createComment(@Valid @RequestBody CommentDto commentDto) {
        return new ResponseEntity<>(commentService.createComment(commentDto), HttpStatus.CREATED);
    }

    @GetMapping
    public List<CommentDto> getCommentByPostId() {
        return commentService.getCommentsByPostId();
    }

    @GetMapping("/{commentId}")
    public ResponseEntity<CommentDto> getCommentById(@PathVariable long commentId) {
        CommentDto apiResonseDto = commentService.getCommentById(commentId);
        return new ResponseEntity<>(apiResonseDto, HttpStatus.OK);
    }

}