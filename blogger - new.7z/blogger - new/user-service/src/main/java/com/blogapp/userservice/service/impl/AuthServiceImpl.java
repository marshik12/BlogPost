package com.blogapp.userservice.service.impl;

import com.blogapp.userservice.dto.APIResonseDtoNew;
import com.blogapp.userservice.dto.LoginDto;
import com.blogapp.userservice.dto.PostDto;
import com.blogapp.userservice.dto.RegisterDto;
import com.blogapp.userservice.entity.User;
import com.blogapp.userservice.exception.BlogAPIException;
import com.blogapp.userservice.exception.ResourceNotFoundException;
import com.blogapp.userservice.repository.UserRepository;
import com.blogapp.userservice.service.AuthService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class AuthServiceImpl implements AuthService {

    private UserRepository userRepository;

    private ModelMapper mapper;

    private RestTemplate restTemplate;

    @Override
    public String register(RegisterDto registerDto) {

        //add check for username exists in database
        if(userRepository.existsByUsername(registerDto.getUsername())){
            throw new BlogAPIException(HttpStatus.BAD_REQUEST,"Username is already exists!.");
        }

        //add check for email exists in database
        if(userRepository.existsByEmail(registerDto.getEmail())){
            throw new BlogAPIException(HttpStatus.BAD_REQUEST,"Email is already exists!.");
        }

        User user = new User();
        user.setName(registerDto.getName());
        user.setUsername(registerDto.getUsername());
        user.setEmail(registerDto.getEmail());
        user.setPassword(registerDto.getPassword());
        user.setPostId(registerDto.getPostId());

        userRepository.save(user);
        return "User registered successfully!.";
    }

    @Override
    public List<RegisterDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map(post -> mapToDTO2(post)).collect(Collectors.toList());
    }

    @Override
    public APIResonseDtoNew getByUserId(long id) {
        User user = userRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("User", "id", id));

        System.out.println("NEWEST********* " + user.getPostId());

        ResponseEntity<PostDto> responseEntity = restTemplate.getForEntity("http://localhost:8081/api/posts/" + user.getPostId(),
                PostDto.class);

        PostDto postDto = responseEntity.getBody();



        RegisterDto registerDto = mapToDTO2(user);

        APIResonseDtoNew apiResonseDtoNew = new APIResonseDtoNew();
        apiResonseDtoNew.setPostDto(postDto);
        apiResonseDtoNew.setRegisterDto(registerDto);

        return apiResonseDtoNew;
    }

    @Override
    public void followerUser(Long followerId, Long followedId) {
        User follower = userRepository.findById(followerId).orElse(null);
        User followed = userRepository.findById(followedId).orElse(null);
        if(follower != null && followed != null){
            follower.getFollowing().add(followed);
            followed.getFollowers().add(follower);
            userRepository.save(follower);
            userRepository.save(followed);
        }
    }

    @Override
    public List<PostDto> getUserPosts(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? new ArrayList<>((int) user.getPostId()) : Collections.emptyList();
    }

    @Override
    public List<PostDto> getFollowers(Long user) {
        User user1 = userRepository.findById(user).orElse(null);
        return user1 != null ? new ArrayList<>((Set)user1.getFollowing()) : Collections.emptyList();
    }

    private User mapToEntity1(LoginDto loginDto){

        User user = mapper.map(loginDto,User.class);
        return user;
    }

    private LoginDto mapToDTO1(User user){

        LoginDto loginDto = mapper.map(user,LoginDto.class);
        return loginDto;
    }

    private User mapToEntity2(RegisterDto registerDto){

        User user = mapper.map(registerDto,User.class);
        return user;
    }

    private RegisterDto mapToDTO2(User user){

        RegisterDto registerDto = mapper.map(user,RegisterDto.class);
        return registerDto;
    }
}
